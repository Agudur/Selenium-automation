package com.aarthireddytesting.base_framework;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

import utilities.configuration;

public class WebDriverManager {

	public static WebDriver Instance = null;
	private static final String CHROME_DRIVER_PROPERTY = "webdriver.chrome.driver";
	private static final String IE_DRIVER_PROPERTY = "webdriver.ie.driver";

	public static void initialize() {

		if (Instance == null && configuration.browser.browser.equalsIgnoreCase("firefox")) {

			Instance = new FirefoxDriver();

		} else if (configuration.browser.browser.equalsIgnoreCase("chrome")) {
			System.setProperty(CHROME_DRIVER_PROPERTY, "src/test/java/WebDrivers/chromedriver.exe");
			Instance = new ChromeDriver();
		} else if (configuration.browser.browser.equalsIgnoreCase("ie")) {
			System.setProperty(IE_DRIVER_PROPERTY, "null");
			Instance = new InternetExplorerDriver();
		} else {
			System.out.println("Sample Testing voided");
		}

		Instance.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		Instance.manage().window().maximize();
	}

	public void close() {
		Instance.close();
		System.out.println("closing the browser");
	}

}
