package utilities;

public class configuration {

	
	
	public static class appurl{
		public static String ap_url = "https://devtaxpfl.does.dc.gov/" + 
				"/";
		
	}
	 public static class browser{ 
		public static String browser = "chrome";
	}
	
}
