package com.aarthireddytesting.base_framework;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import utilities.configuration;

/**
 * Unit test for simple App.
 */
public class AppTest 
{
@BeforeClass
	public static void setup() {
		WebDriverManager.initialize();
	}

@Test
public void Test1(){
	System.out.println("url is:" + configuration.appurl.ap_url);
	WebDriverManager.Instance.navigate().to(configuration.appurl.ap_url);
}

	/*
	 * @AfterClass public static void cleanup() {
	 * 
	 * WebDriverManager.Instance.close(); }
	 */
}