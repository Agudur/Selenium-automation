package com.aarthireddytesting.base_framework;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;

import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import gherkin.deps.com.google.gson.annotations.Until;
import utilities.configuration;

public class GenericSteps extends HomePage{
	WebDriver driver;
	HomePage home;
	

	@Given("^I am on the homepage$")
	public void i_am_on_the_homepage(){
		 
		/*
		 * String loclurl= configuration.appurl.ap_url; WebDriverManager.initialize();
		 * WebDriverManager.Instance.navigate().to(loclurl);
		 */
		 System.setProperty("webdriver.chrome.driver","C:\\Users\\arathi.gudur\\eclipse-workspace\\base-framework\\src\\test\\java\\WebDrivers\\chromedriver.exe");
		 driver = new ChromeDriver();
		 driver.get("https://systaxpfl.does.dc.gov");
		 		// driver.get("https://uattaxpfl.does.dc.gov");
				 //driver.get("https://devtaxpfl.does.dc.gov");
		 driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS) ;

	   
	}




	@Then("^Click on Employer tab$")
	public void click_on_Employer_tab() throws InterruptedException {
	
		Thread.sleep(3000);
	   
	
		driver.findElement(By.xpath("/html/body/div/div[2]/div[2]/div/button")).click();
	  
	}

	@Then("^Click on Register  for a new account$")
	public void click_on_Register_for_a_new_account() throws Throwable {
		Thread.sleep(3000);
		driver.findElement(By.xpath("/html/body/div/div[1]/div[2]/p[2]/button [2]/b")).click();
		}

	@Then("^Click on DOES Portal Next$")
	public void click_on_DOES_Portal_Next() throws Throwable {
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id='wizMain']/div[2]/a[2]")).click();
				}

	@Then("^Enter \"([^\"]*)\"credntials$")
	public void enter_credntials(String user) throws Throwable {
		Thread.sleep(3000);
	  driver.findElement(By.xpath("//*[@id=\"txtUserId\"]")).sendKeys(user);//USername
	  
	  driver.findElement(By.xpath("//*[@id=\"txtPassword\"]")).sendKeys("Password@10");//Password
	  driver.findElement(By.xpath("//*[@id=\"txtIstrConfirmPassword\"]")).sendKeys("Password@10");//Confirm Password
	//driver.findElement(By.xpath("//*[@id=\"ddlDropDownList3\"]")).click();
	
	Select drp1= new Select(driver.findElement(By.xpath("//*[@id=\"ddlDropDownList3\"]")));
	
	 drp1.selectByIndex(1);
	  Thread.sleep(3000);
	  
	  driver.findElement(By.xpath("//*[@id=\"txtTextBox10\"]")).sendKeys("ppp");

	  driver.findElement(By.xpath("//*[@id=\"txtTextBox11\"]")).sendKeys("ppp");

	  Thread.sleep(3000);
	  Select drp2= new Select(driver.findElement(By.xpath("//*[@id=\"ddlDropDownList1\"]")));
		
		 drp2.selectByIndex(2);
		  Thread.sleep(3000);
		  
		  driver.findElement(By.xpath("//*[@id=\"txtTextBox13\"]")).sendKeys("aaa");
		  driver.findElement(By.xpath("//*[@id=\"txtTextBox14\"]")).sendKeys("aaa");
	  

		  Select drp3= new Select(driver.findElement(By.xpath("//*[@id=\"ddlDropDownList4\"]")));
			
			 drp3.selectByIndex(3);
			  
			  driver.findElement(By.xpath("//*[@id=\"txtTextBox15\"]")).sendKeys("bbb");
			  driver.findElement(By.xpath("//*[@id=\"txtTextBox16\"]")).sendKeys("bbb");
			  
			  driver.findElement(By.xpath("//*[@id=\"wizMain\"]/div[2]/a[2]")).click();
			  Thread.sleep(3000);
			  
			  

	}
	@Then("^Click on Next Button$")
	public void click_on_Next_Button() {
		  driver.findElement(By.xpath("//*[@id=\"wizMain\"]/div[2]/a[2]")).click();
		  

	}

	@Then("^Enter The Contact Info$")
	public void enter_The_Contact_Info() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	driver.findElement(By.id("txtTextBox2")).sendKeys("Software Corn");
	driver.findElement(By.xpath("//*[@id=\"txtFirstName\"]")).sendKeys("Arathi101");
	driver.findElement(By.xpath("//*[@id=\"txtLastName\"]")).sendKeys("Reddy");

	driver.findElement(By.xpath("//*[@id=\"txtCIAddress1\"]")).sendKeys("1667 K Street NW ");
	driver.findElement(By.xpath("//*[@id=\"txtCIAddress2\"]")).sendKeys("200");
	driver.findElement(By.xpath("//*[@id=\"txtCICity\"]")).sendKeys("Washinton");

	driver.findElement(By.xpath("//*[@id=\"txtCIZip\"]")).sendKeys("20006");
	//driver.findElement(By.cssSelector("#txtPNumber")).sendKeys("9090001234");
Thread.sleep(2000);
driver.findElement(By.xpath("//*[@id='txtPNumber']")).click();
	driver.findElement(By.xpath("//*[@id='txtPNumber']")).sendKeys("9995555444");

	driver.findElement(By.xpath("//*[@id=\"txtTextBox18\"]")).sendKeys("arathi.gudur@sagitec.com");
	driver.findElement(By.xpath("//*[@id=\"txtTextBox19\"]")).sendKeys("arathi.gudur@sagitec.com");
	
	Thread.sleep(5000);
	driver.findElement(By.xpath("//*[@id=\"btnValidatePrimary\"]")).click();
	Thread.sleep(3000);
driver.findElement(By.xpath("//*[@id=\"wizMain\"]/div[2]/a[2]")).click();
Thread.sleep(3000);
	}

	
	@Then("^Click On Yes$")
	public void click_On_Yes() throws Throwable {
driver.findElement(By.xpath("//*[@id=\"rblpaid_wages_ind_1\"]")).click();
driver.findElement(By.xpath("//*[@id=\"wizMain\"]/div[2]/a[2]")).click();
Thread.sleep(3000);
}

	@Then("^Enter \"([^\"]*)\" Questions$")
	public void enter_Questions(String fien) throws Throwable  {
		driver.findElement(By.xpath("//*[@id=\"rblphysical_location_ind_1\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"txtSerVBegin\"]")).click();

		driver.findElement(By.xpath("//*[@id=\"txtSerVBegin\"]")).sendKeys("01/01/2019");
		
		driver.findElement(By.xpath("//*[@id=\"txtPaymentFirstDate\"]")).click();

		driver.findElement(By.xpath("//*[@id=\"txtPaymentFirstDate\"]")).sendKeys("01/01/2019");

		driver.findElement(By.xpath("//*[@id=\"txtCompanindisual\"]")).sendKeys("50");
		driver.findElement(By.xpath("//*[@id=\"txtFerderal_Employee_Id\"]")).click();

		//FIN
		driver.findElement(By.xpath("//*[@id=\"txtFerderal_Employee_Id\"]")).sendKeys(fien);

driver.findElement(By.xpath("//*[@id=\"rblFutaDec_0\"]")).click();

driver.findElement(By.xpath("//*[@id=\"rblDomesticService_0\"]")).click();
driver.findElement(By.xpath("//*[@id=\"wizMain\"]/div[2]/a[2]")).click();
Thread.sleep(3000);
		
	}

	@Then("^Enter business Information$")
	public void enter_business_Information() throws Throwable {
		 Select drp4= new Select(driver.findElement(By.xpath("//*[@id=\"ddlLegalentityType\"]")));
		 drp4.selectByIndex(8);
		  Thread.sleep(3000);
		  
			driver.findElement(By.xpath("//*[@id=\"txtlegalName\"]")).sendKeys("Software Class");
			driver.findElement(By.xpath("//*[@id=\"txtTextBox1\"]")).click();
			driver.findElement(By.xpath("//*[@id=\"txtTextBox1\"]")).sendKeys("01/01/2019");

			driver.findElement(By.xpath("//*[@id=\"wizMain\"]/div[2]/a[2]")).click();
			Thread.sleep(3000);
					
	}

	@Then("^Enter Business Additional Bussiness Information$")
	public void enter_Business_Additional_Bussiness_Information() throws Throwable {
		driver.findElement(By.xpath("//*[@id=\"rblRadioButtonList6_1\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"rblRadioButtonList7_1\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"rblform_1099_worker_ind_1\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"rblChange_fein_ind_0\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"rblAcquisition_merger_ind_0\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"txtMultiLocation\"]")).sendKeys("1");

		driver.findElement(By.xpath("//*[@id=\"wizMain\"]/div[2]/a[2]")).click();
		Thread.sleep(3000);
		
		
		driver.findElement(By.xpath("//*[@id=\"txtDCAddressAttention\"]")).sendKeys("Arathi");
		driver.findElement(By.xpath("//*[@id=\"txtEAAddress1\"]")).sendKeys("1667 K Street NW");
		driver.findElement(By.xpath("//*[@id=\"txtEAAddress2\"]")).sendKeys("200");
		driver.findElement(By.xpath("//*[@id=\"txtEAZipCode\"]")).sendKeys("20006");
		driver.findElement(By.xpath("//*[@id=\"txtTextBox8\"]")).sendKeys("arathi.gudur.sagitec.com");
		 Select drp5= new Select(driver.findElement(By.xpath("//*[@id=\"ddlWardEA\"]")));
		 drp5.selectByIndex(2);
		
		
		driver.findElement(By.xpath("//*[@id=\"txtTextBox12\"]")).sendKeys("arathi.gudur@sagitec.com");
		driver.findElement(By.xpath("//*[@id=\"btnValidateEAAddress\"]")).click();
		
		Thread.sleep(3000);

		driver.findElement(By.xpath("//*[@id=\"tblNewPage13\"]/tbody/tr[1]/td/label")).click();
		Thread.sleep(3000);

		driver.findElement(By.xpath("//*[@id=\"chkCheckBox\"]")).click();

		

		driver.findElement(By.xpath("//*[@id=\"wizMain\"]/div[2]/a[2]")).click();
		Thread.sleep(3000);


	}

	@Then("^Enter NAICS Details$")
	public void enter_NAICS_Details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 Select drp6= new Select(driver.findElement(By.xpath("//*[@id=\"ddl1StQualification\"]")));
		 drp6.selectByIndex(2);
		 Select drp7= new Select(driver.findElement(By.xpath("//*[@id=\"ddl2ndQualification\"]")));
		 drp7.selectByIndex(2);
		 Select drp8= new Select(driver.findElement(By.xpath("//*[@id=\"ddl3rdQualification\"]")));
		 drp8.selectByIndex(2);
		 Select drp9= new Select(driver.findElement(By.xpath("//*[@id=\"ddl4thQualification\"]")));
		 drp9.selectByIndex(2);
		 Select drp10= new Select(driver.findElement(By.xpath("//*[@id=\"ddl5thQualification\"]")));
		 drp10.selectByIndex(2);
			driver.findElement(By.xpath("//*[@id=\"txtTextBox6\"]")).sendKeys("Arathi RR");

			driver.findElement(By.xpath("//*[@id=\"wizMain\"]/div[2]/a[2]")).click();
			Thread.sleep(3000);
	
			
					
	}



	@Then("^Enter \"([^\"]*)\" Information$")
	public void enter_Information(String ssn) throws Throwable {
    // Write code here that turns the phrase above into concrete action

	
	//Add details
	driver.findElement(By.xpath("//*[@id=\"btnWizardAddNewChildClick\"]")).click();
	Thread.sleep(3000);
	 Select drp11= new Select(driver.findElement(By.xpath("//*[@id=\"ddlDropDownList7\"]")));
	 drp11.selectByIndex(1);

		driver.findElement(By.xpath("//*[@id=\"txtFirstNameIndiv\"]")).sendKeys("Arathi");
		driver.findElement(By.xpath("//*[@id=\"txtLastIndiv\"]")).sendKeys("Reddy");
		driver.findElement(By.xpath("//*[@id=\"txtSSNIndiv1\"]")).click();
		//SSN
		driver.findElement(By.xpath("//*[@id=\"txtSSNIndiv1\"]")).sendKeys(ssn);
		
		//*[@id="ddlBtitle"]

		Select drop = new Select(driver.findElement(By.cssSelector("#ddlBtitle")));
/*
 * Select drp12= new
 * Select(driver.findElement(By.xpath("//*[@id=\"ddlBtitle\"]]")));
 */				 drop.selectByIndex(2);
 
	driver.findElement(By.xpath("//*[@id=\"txtPartOwner\"] ")).clear();

		driver.findElement(By.xpath("//*[@id=\"txtPartOwner\"] ")).sendKeys("100");
		
			driver.findElement(By.xpath("//*[@id=\"txtFirstPartOwner\"]")).click();
			
			driver.findElement(By.xpath("//*[@id=\"txtFirstPartOwner\"]")).sendKeys("01/01/2019");
			driver.findElement(By.xpath("//*[@id=\"txtAddressOOILineOne\"]")).sendKeys("1667 K Street NW ");
			driver.findElement(By.xpath("//*[@id=\"txtAddressOOILineTwo\"]")).sendKeys("200");

	

			driver.findElement(By.xpath("//*[@id=\"txtCityOOI\"]")).sendKeys("Washington");
			driver.findElement(By.xpath("//*[@id=\"txtOOIZip\"]")).sendKeys("20006");
			
	
			
			driver.findElement(By.cssSelector("#txtOwnPNumber")).click();
			driver.findElement(By.cssSelector("#txtOwnPNumber")).sendKeys("2023456789");

			

			//driver.findElement(By.xpath("//*[@id=\\\"txtOwnPNumber\\\"]")).click();
			//driver.findElement(By.xpath("//*[@id=\"txtOwnPNumber\"]")).sendKeys("7033036045");
			

			driver.findElement(By.xpath("//*[@id=\"txtEmailOOI\"]")).sendKeys("arathi.gudur@sagitec.com");

			driver.findElement(By.xpath("//*[@id=\"txtTextBox17\"]")).sendKeys("arathi.gudur@sagitec.com");
			
			driver.findElement(By.cssSelector("#btnValidateOwnerAddress")).click();
			
			//driver.findElement(By.xpath("///*[@id=\"btnValidateOwnerAddress\"]")).click();
			Thread.sleep(5000);
			

}

@Then("^Enter Additional Ownership Information$")
public void enter_Additional_Ownership_Information() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	
	// Add owner information
driver.findElement(By.xpath("//*[@id=\"wizMain\"]/div[2]/a[2]")).click();

Thread.sleep(3000);
driver.findElement(By.xpath("//*[@id=\"GridTable_grvOwnerOfficer\"]/table/tbody/tr/td[1]/input")).click();

driver.findElement(By.xpath("//*[@id=\"wizMain\"]/div[2]/a[2]")).click();

Thread.sleep(3000);

}

@Then("^Enter Review and Submit$")
public void enter_Review_and_Submit() throws Throwable {
	
	driver.findElement(By.cssSelector("#chkIstrAgreeTermsAndConditions")).click();
	//driver.findElement(By.xpath("//*[@id=\"chkIstrAgreeTermsAndConditions\"]")).click();
	Thread.sleep(3000);

	driver.findElement(By.xpath("//*[@id=\"wizMain\"]/div[2]/a[2]")).click();

	Thread.sleep(15000);
}

@Then("^Click Finish$")
public void click_Finish() throws Throwable {
	//driver.findElement(By.xpath("//*[@id=\\\"wizMain\\\"]/div[2]/a[1]")	
	driver.findElement(By.xpath("//*[@id=\"wizMain\"]/div[2]/a[1]")).click();

	Thread.sleep(15000);

	driver.quit();
}



}